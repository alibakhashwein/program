$(document).ready(function () {
    $('.bars-toggle i').click(function () { 
        $('nav').toggleClass('navtoggle');
        

        // $('nav .container .logo').removeClass('index');
        
    });


    $('.x-toggle i').click(function () { 
        $('nav').toggleClass('navtoggle');
        $('nav').css('transition', '.7s');

        // $('nav .container .logo').addClass('index');
        
    });

    $('section').click(function () { 
        $('nav').removeClass('navtoggle');
        $('nav').css('transition', '.7s');
        
    });

    $('nav .container ul li').click(function () { 
        $('nav').removeClass('navtoggle');
        $('nav').css('transition', '.7s');
        
    });

    $('nav .container ul li a').click(function () { 
        $('nav').removeClass('navtoggle');
        $('nav').css('transition', '.7s');
        
    });
});